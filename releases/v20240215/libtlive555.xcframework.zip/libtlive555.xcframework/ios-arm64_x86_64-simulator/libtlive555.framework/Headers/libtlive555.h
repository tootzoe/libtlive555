//
//  libtlive555.h
//  libtlive555
//
//  Created by thor on 10/3/24
//  
//
//  Email: toot@tootzoe.com  Tel: +855 69325538 
//
//

//
//
//#import <Foundation/Foundation.h>
//
////! Project version number for libtlive555.
//FOUNDATION_EXPORT double libtlive555VersionNumber;
//
////! Project version string for libtlive555.
//FOUNDATION_EXPORT const unsigned char libtlive555VersionString[];
//
//// In this header, you should import all the public headers of your framework using statements like #import <libtlive555/PublicHeader.h>
//
//
